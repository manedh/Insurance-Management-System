package com.sawai.insurance.config;

import com.sawai.insurance.entity.User;
import com.sawai.insurance.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Optional;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private UserRepository userRepository;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        String path = request.getRequestURI();
        String method = request.getMethod();

        // Allow login, swagger, static, and OPTIONS (CORS preflight)
        if (path.startsWith("/api/auth/login")
                || path.startsWith("/v3/api-docs")
                || path.startsWith("/swagger-ui")
                || path.equals("/swagger-ui.html")
                || "OPTIONS".equalsIgnoreCase(method)) {
            return true;
        }

        // Only guard /api/**
        if (!path.startsWith("/api/")) {
            return true;
        }

        String token = request.getHeader("X-Auth-Token");
        if (token == null || token.isBlank()) {
            response.sendError(HttpStatus.UNAUTHORIZED.value(),
                    "Missing X-Auth-Token header");
            return false;
        }

        Optional<User> userOpt = userRepository.findByToken(token);
        if (userOpt.isEmpty()) {
            response.sendError(HttpStatus.UNAUTHORIZED.value(),
                    "Invalid X-Auth-Token");
            return false;
        }

        User user = userOpt.get();

        // AGENT cannot DELETE
        if ("DELETE".equalsIgnoreCase(method) && !"ADMIN".equalsIgnoreCase(user.getRole())) {
            response.sendError(HttpStatus.FORBIDDEN.value(),
                    "AGENT role is not authorized to perform DELETE");
            return false;
        }

        // Attach user info to request attributes for downstream use
        request.setAttribute("authUser", user);
        return true;
    }
}
