package com.sawai.insurance.config;

import com.sawai.insurance.entity.User;
import com.sawai.insurance.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository userRepository;

    public DataSeeder(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void run(String... args) {
        if (userRepository.findByUsername("admin").isEmpty()) {
            userRepository.save(User.builder()
                    .username("admin")
                    .password("admin123")
                    .role("ADMIN")
                    .token("admin-token-123")
                    .build());
        }
        if (userRepository.findByUsername("agent").isEmpty()) {
            userRepository.save(User.builder()
                    .username("agent")
                    .password("agent123")
                    .role("AGENT")
                    .token("agent-token-123")
                    .build());
        }
    }
}
