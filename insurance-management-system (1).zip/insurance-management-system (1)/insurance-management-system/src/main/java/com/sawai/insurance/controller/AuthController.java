package com.sawai.insurance.controller;

import com.sawai.insurance.dto.LoginRequest;
import com.sawai.insurance.entity.User;
import com.sawai.insurance.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest req) {
        Optional<User> userOpt = authService.login(req.getUsername(), req.getPassword());
        if (userOpt.isEmpty()) {
            Map<String, Object> err = new HashMap<>();
            err.put("message", "Invalid username or password");
            return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
        }
        User user = userOpt.get();
        Map<String, Object> body = new HashMap<>();
        body.put("token", user.getToken());
        body.put("username", user.getUsername());
        body.put("role", user.getRole());
        return ResponseEntity.ok(body);
    }
}
