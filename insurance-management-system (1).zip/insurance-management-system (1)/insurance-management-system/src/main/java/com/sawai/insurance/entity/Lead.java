package com.sawai.insurance.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity
@Table(name = "leads")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Lead {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long leadId;

    @NotBlank(message = "Prospect name is required")
    @Column(nullable = false)
    private String prospectName;

    @NotBlank(message = "Contact info is required")
    @Column(nullable = false)
    private String contactInfo;

    @NotBlank(message = "Referral source is required")
    @Column(nullable = false)
    private String referralSource;

    @NotBlank(message = "Lead status is required")
    @Column(nullable = false)
    private String leadStatus; // NEW, CONTACTED, QUALIFIED, CONVERTED, LOST

    @NotBlank(message = "Assigned agent name is required")
    @Column(nullable = false)
    private String assignedAgentName;
}
