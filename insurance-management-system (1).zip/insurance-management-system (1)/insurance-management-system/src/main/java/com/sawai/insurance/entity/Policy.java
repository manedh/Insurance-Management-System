package com.sawai.insurance.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "policies")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Policy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long policyId;

    @NotBlank(message = "Policy number is required")
    @Column(nullable = false, unique = true)
    private String policyNumber;

    @NotBlank(message = "Policy name is required")
    @Column(nullable = false)
    private String policyName;

    @NotBlank(message = "Policy type is required")
    @Column(nullable = false)
    private String policyType; // LIFE, HEALTH, AUTO, HOME

    @NotNull(message = "Premium amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Premium must be > 0")
    @Column(nullable = false)
    private BigDecimal premiumAmount;

    @NotBlank(message = "Coverage term is required")
    @Column(nullable = false)
    private String coverageTerm; // e.g. "12 months", "5 years"

    @NotNull(message = "Effective start date is required")
    private LocalDate effectiveStartDate;

    @NotNull(message = "Customer ID is required")
    @Column(nullable = false)
    private Long customerId;
}
