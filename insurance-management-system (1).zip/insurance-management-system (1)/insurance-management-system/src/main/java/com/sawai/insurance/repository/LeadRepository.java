package com.sawai.insurance.repository;

import com.sawai.insurance.entity.Lead;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeadRepository extends JpaRepository<Lead, Long> {

    List<Lead> findByProspectNameContainingIgnoreCaseOrLeadStatusContainingIgnoreCaseOrAssignedAgentNameContainingIgnoreCase(
            String prospectName, String leadStatus, String assignedAgentName);
}
