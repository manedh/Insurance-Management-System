package com.sawai.insurance.repository;

import com.sawai.insurance.entity.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {

    Optional<Policy> findByPolicyNumber(String policyNumber);

    List<Policy> findByCustomerId(Long customerId);

    List<Policy> findByPolicyNumberContainingIgnoreCaseOrPolicyNameContainingIgnoreCaseOrPolicyTypeContainingIgnoreCase(
            String policyNumber, String policyName, String policyType);
}
