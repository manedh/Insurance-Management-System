package com.sawai.insurance.service;

import com.sawai.insurance.entity.Customer;
import com.sawai.insurance.exception.DuplicateResourceException;
import com.sawai.insurance.exception.ResourceNotFoundException;
import com.sawai.insurance.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    private final CustomerRepository repo;

    public CustomerService(CustomerRepository repo) {
        this.repo = repo;
    }

    public List<Customer> getAll() {
        return repo.findAll();
    }

    public Customer getById(Long id) {
        return repo.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Customer not found with id " + id));
    }

    public Customer create(Customer c) {
        Optional<Customer> existing = repo.findByEmail(c.getEmail());
        if (existing.isPresent()) {
            throw new DuplicateResourceException("Email already exists: " + c.getEmail());
        }
        return repo.save(c);
    }

    public Customer update(Long id, Customer c) {
        Customer existing = getById(id);
        if (!existing.getEmail().equalsIgnoreCase(c.getEmail())) {
            Optional<Customer> conflict = repo.findByEmail(c.getEmail());
            if (conflict.isPresent()) {
                throw new DuplicateResourceException("Email already exists: " + c.getEmail());
            }
        }
        existing.setFirstName(c.getFirstName());
        existing.setLastName(c.getLastName());
        existing.setEmail(c.getEmail());
        existing.setPhoneNumber(c.getPhoneNumber());
        existing.setDateOfBirth(c.getDateOfBirth());
        existing.setAccountStatus(c.getAccountStatus());
        return repo.save(existing);
    }

    public void delete(Long id) {
        Customer existing = getById(id);
        repo.delete(existing);
    }

    public List<Customer> search(String q) {
        if (q == null || q.isBlank()) return repo.findAll();
        return repo.findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCaseOrEmailContainingIgnoreCase(q, q, q);
    }
}
