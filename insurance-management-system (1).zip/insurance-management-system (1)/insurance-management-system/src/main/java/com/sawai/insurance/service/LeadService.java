package com.sawai.insurance.service;

import com.sawai.insurance.entity.Lead;
import com.sawai.insurance.exception.ResourceNotFoundException;
import com.sawai.insurance.repository.LeadRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeadService {

    private final LeadRepository repo;

    public LeadService(LeadRepository repo) { this.repo = repo; }

    public List<Lead> getAll() { return repo.findAll(); }

    public Lead getById(Long id) {
        return repo.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Lead not found with id " + id));
    }

    public Lead create(Lead l) { return repo.save(l); }

    public Lead update(Long id, Lead l) {
        Lead existing = getById(id);
        existing.setProspectName(l.getProspectName());
        existing.setContactInfo(l.getContactInfo());
        existing.setReferralSource(l.getReferralSource());
        existing.setLeadStatus(l.getLeadStatus());
        existing.setAssignedAgentName(l.getAssignedAgentName());
        return repo.save(existing);
    }

    public void delete(Long id) {
        Lead existing = getById(id);
        repo.delete(existing);
    }

    public List<Lead> search(String q) {
        if (q == null || q.isBlank()) return repo.findAll();
        return repo.findByProspectNameContainingIgnoreCaseOrLeadStatusContainingIgnoreCaseOrAssignedAgentNameContainingIgnoreCase(q, q, q);
    }
}
