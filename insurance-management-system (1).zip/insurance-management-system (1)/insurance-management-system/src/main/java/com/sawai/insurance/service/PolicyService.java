package com.sawai.insurance.service;

import com.sawai.insurance.entity.Policy;
import com.sawai.insurance.exception.DuplicateResourceException;
import com.sawai.insurance.exception.ResourceNotFoundException;
import com.sawai.insurance.repository.CustomerRepository;
import com.sawai.insurance.repository.PolicyRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PolicyService {

    private final PolicyRepository repo;
    private final CustomerRepository customerRepo;

    public PolicyService(PolicyRepository repo, CustomerRepository customerRepo) {
        this.repo = repo;
        this.customerRepo = customerRepo;
    }

    public List<Policy> getAll() { return repo.findAll(); }

    public Policy getById(Long id) {
        return repo.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Policy not found with id " + id));
    }

    public Policy create(Policy p) {
        validateCustomer(p.getCustomerId());
        Optional<Policy> existing = repo.findByPolicyNumber(p.getPolicyNumber());
        if (existing.isPresent()) {
            throw new DuplicateResourceException("Policy number already exists: " + p.getPolicyNumber());
        }
        return repo.save(p);
    }

    public Policy update(Long id, Policy p) {
        Policy existing = getById(id);
        validateCustomer(p.getCustomerId());
        if (!existing.getPolicyNumber().equalsIgnoreCase(p.getPolicyNumber())) {
            Optional<Policy> conflict = repo.findByPolicyNumber(p.getPolicyNumber());
            if (conflict.isPresent()) {
                throw new DuplicateResourceException("Policy number already exists: " + p.getPolicyNumber());
            }
        }
        existing.setPolicyNumber(p.getPolicyNumber());
        existing.setPolicyName(p.getPolicyName());
        existing.setPolicyType(p.getPolicyType());
        existing.setPremiumAmount(p.getPremiumAmount());
        existing.setCoverageTerm(p.getCoverageTerm());
        existing.setEffectiveStartDate(p.getEffectiveStartDate());
        existing.setCustomerId(p.getCustomerId());
        return repo.save(existing);
    }

    public void delete(Long id) {
        Policy existing = getById(id);
        repo.delete(existing);
    }

    public List<Policy> search(String q) {
        if (q == null || q.isBlank()) return repo.findAll();
        return repo.findByPolicyNumberContainingIgnoreCaseOrPolicyNameContainingIgnoreCaseOrPolicyTypeContainingIgnoreCase(q, q, q);
    }

    private void validateCustomer(Long customerId) {
        if (customerId == null || customerRepo.findById(customerId).isEmpty()) {
            throw new ResourceNotFoundException("Customer not found with id " + customerId);
        }
    }
}
