// Common helpers shared across pages
const API_BASE = window.location.origin + "/api";

function getToken() {
    return localStorage.getItem("authToken");
}
function getUsername() {
    return localStorage.getItem("authUsername");
}
function getRole() {
    return localStorage.getItem("authRole");
}
function saveAuth(token, username, role) {
    localStorage.setItem("authToken", token);
    localStorage.setItem("authUsername", username);
    localStorage.setItem("authRole", role);
}
function clearAuth() {
    localStorage.removeItem("authToken");
    localStorage.removeItem("authUsername");
    localStorage.removeItem("authRole");
}
function logout() {
    clearAuth();
    window.location.href = "index.html";
}
function requireAuth() {
    if (!getToken()) {
        window.location.href = "index.html";
    }
}
function showMessage(elId, text, type) {
    const el = document.getElementById(elId);
    if (!el) return;
    el.textContent = text;
    el.className = "msg " + (type || "success");
    el.style.display = "block";
    setTimeout(() => { el.style.display = "none"; }, 4000);
}
function renderHeader() {
    const info = document.getElementById("userInfo");
    if (info) {
        info.textContent = getUsername() + " (" + getRole() + ")";
    }
}
async function apiCall(path, method, body) {
    const opts = {
        method: method || "GET",
        headers: { "Content-Type": "application/json" }
    };
    const token = getToken();
    if (token) opts.headers["X-Auth-Token"] = token;
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API_BASE + path, opts);
    if (res.status === 401) {
        alert("Session expired. Please login again.");
        logout();
        throw new Error("Unauthorized");
    }
    if (res.status === 403) {
        alert("Access denied: AGENT cannot perform DELETE.");
        throw new Error("Forbidden");
    }
    if (!res.ok) {
        let errText = "Request failed (" + res.status + ")";
        try {
            const data = await res.json();
            if (data.message) errText = data.message;
            else if (data.errors) errText = JSON.stringify(data.errors);
        } catch (e) {}
        throw new Error(errText);
    }
    if (res.status === 204) return null;
    return res.json();
}
